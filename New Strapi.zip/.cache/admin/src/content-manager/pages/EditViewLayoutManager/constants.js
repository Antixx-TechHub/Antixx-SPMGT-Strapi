export const SET_LAYOUT = 'ContentManager/EditViewLayoutManager/SET_LAYOUT';
export const RESET_PROPS = 'ContentManager/EditViewLayoutManager/RESET_PROPS';
