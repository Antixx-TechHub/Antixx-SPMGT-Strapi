import { createContext } from 'react';

const AdminContext = createContext({});

export default AdminContext;
