#!/usr/bin/env node
'use strict'; 

// Start Strapi
const strapi = require('@strapi/strapi');
strapi().start();
